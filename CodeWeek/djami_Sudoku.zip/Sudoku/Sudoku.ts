let grid : number[][] = [
    [-5, -4, 0, 0, -2, 0, -8, 0, -6],
    [0, -1, -9, 0, 0, -7, 0, 0, -3],
    [0, 0, 0, -3, 0, 0, -2, -1, 0],
    [-9, 0, 0, -4, 0, -5, 0, -2, 0],
    [0, 0, -1, 0, 0, 0, -6, 0, -4],
    [-6, 0, -4, 0, -3, -2, 0, -8, 0],
    [0, -6, 0, 0, 0, 0, -1, -9, 0],
    [-4, 0, -2, 0, 0, -9, 0, 0, -5],
    [0, -9, 0, 0, -7, 0, -4, 0, -2]
]

update_grid(grid);

function input(val:number,pos_i:number,pos_j:number){
    
    if (val>=0){
        grid[pos_i][pos_j] = val
        update_grid(grid)
    }
    let check = check_grid()
    if (check == false){
        display_error(true)  
    }

    else{
        display_error(false)
    }
    if (check_fill()== true && check==true) {
        display_win()
    }

    console.log(val," ",pos_i," ",pos_j)
   
    console.log("check line : " , check_line(pos_i))
   
    console.log("check col : " , check_col(pos_j))
   
    let nreg:number= (Math.floor(pos_i/3))*3 + (Math.floor(pos_j/3))
   
    console.log("nreg : " , nreg)
   
    console.log("check_reg : ", check_reg(nreg))
}


function check_line(index:number) {
    let line:number[] = grid[index]
    for (let i=0;i<line.length;i++){
        if (has_double(line, line[i]) == true){
            return false
        }
    }
    return true
}

function check_col(index:number) {
    let col:number[]=[]
    for (let i=0;i<9;i++){
        col.push(grid[i][index])
    }

    for (let i=0;i<9;i++){
        if(has_double(col,col[i]) == true){
            return false
        }
        
    }
    return true
}

function check_reg(index:number) {
    let reg:number[]=[]
   
    let line_start = (Math.floor(index/3))*3
    let line_end = line_start + 3
   
    let col_start = (index%3)*3
    let col_end = col_start + 3
 
    for (let i=line_start;i<line_end;i++){
        for (let j=col_start;j<col_end;j++){
            reg.push(grid[i][j])
        }
    }

    for (let i=0; i<reg.length;i++){
        for (let j=0;j<reg.length;j++){
            if (has_double(reg, reg[j]) == true) {
                return false
            }
        }
    }
    return true
}

function check_grid() : boolean {
    for (let i=0;i< 9;i++){
        if (check_line(i) == false || check_col(i) == false || check_reg(i)== false) {
            return false
        }
    }
    return true
}
 
function check_fill() : boolean {
    for (let i=0;i<grid.length;i++){
        for (let j=0;j<grid[i].length;j++){
            if (grid[i][j]==0){
                return false
            }
        }
    }
    return true
}

function has_double(l:number[],n:number) {
    if (n==0){
        return false
    }

    let cpt:number=0
    for (let i=0;i<l.length;i++){
        
        if (Math.abs(l[i])==Math.abs(n)) {
            cpt=cpt+1
        }
        
    }
    if (cpt<=1){
        return false
    }

    else {
        return true
    }
}