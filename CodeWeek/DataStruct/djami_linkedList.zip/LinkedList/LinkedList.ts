/*Implémentation d'une LinkedList en TypeScript :
L'objectif de cet exercice est de concevoir et d'implémenter une structure de données appelée liste chaînée (ou LinkedList) 
Une liste chaînée est une structure de données linéaire où chaque élément est un nœud contenant à la fois des données et 
une référence vers le nœud suivant dans la séquence.

Fonctionnalités attendues :

Création d'une classe Node représentant un nœud de la liste chaînée. Chaque nœud doit contenir une valeur de données et 
une référence vers le prochain nœud.

Création d'une classe LinkedList pour gérer la liste chaînée. Cette classe doit fournir les fonctionnalités suivantes :

Ajouter un élément à la fin de la liste.
Insérer un élément à une position spécifique dans la liste.
Supprimer un élément à une position spécifique de la liste.
Afficher les éléments de la liste dans l'ordre.

Exemple :
Liste initiale : 1 -> 2 -> 3 -> 4
En ajoutant l'élément 5 à la fin de la liste, en insérant l'élément 10 à la position 2, 
et en supprimant l'élément à la position 1, la liste doit ressembler à ceci :
Liste finale : 1 -> 10 -> 2 -> 3 -> 5

Veillez à ce que votre implémentation gère correctement les cas :
- où la liste est vide,
- où une insertion/suppression est tentée à une position invalide.
Vous pouvez choisir d'implémenter des méthodes supplémentaires pour d'autres opérations sur la liste chaînée.*/

class ListNode<T> {
    value: T;
    next: ListNode<T> | undefined;

    constructor(value: T) {
        this.value = value;
        this.next = undefined;
    }
}

class LinkedList<T> {
    head: ListNode<T> | undefined;
    constructor() {
        this.head = undefined;
    }

    add(data: T): void {
        let new_node = new ListNode(data);
        if (this.head == undefined) {
            this.head = new_node;
        }
        else {
            let current: ListNode<T> | undefined = this.head;
            while (current.next != undefined) {
                current = current.next;
            }
            current.next = new_node;
        }
    }

    insertAt(data: T, index: number): void {
        if (index < 0) {
            console.log("index doit depasser 0")
            return
        }
        let new_node = new ListNode(data);
        let previous: ListNode<T> | undefined;

        let current: ListNode<T> | undefined = this.head;
        for (let i = 0; i < index; i++) {
            if (current == undefined) {
                console.log("index en dehors de la liste")
                return
            }
            else {
                previous = current;
                current = current.next;
            }
        }

        new_node.next = current;

        if (previous) {
            previous.next = new_node;
        }
    }

    removeFrom(index: number): void {
        let current: ListNode<T> | undefined = this.head;
        let previous: ListNode<T> | undefined = current;

        if (current == undefined) {
            return
        }

        for (let i = 0; i < index; i++) {
            if (current == undefined) {
                console.log("index en dehors de la liste");
                return
            }

            else {
                previous = current;
                current = current.next;
            }
        }

        if (previous != undefined && current != undefined) {
            previous.next = current.next;
        }
    }

    display(): string {
        let res: string = '';
        let current: ListNode<T> | undefined = this.head;
        while (current != undefined) {
            res += current.value + (current.next ? ' -> ' : '');
            current = current.next;
        }
        return res;
    }
}

let linked_list = new LinkedList<number>();
linked_list.add(1);
linked_list.add(2);
linked_list.add(3);
linked_list.add(4);

console.log(linked_list.display()); // Affiche : 1 2 3 4

linked_list.insertAt(5, 2);
console.log(linked_list.display()); // Affiche : 1 2 5 3 4

linked_list.removeFrom(1);
console.log(linked_list.display()); // Affiche : 1 5 3 4